package com.techstore.ordersapi;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface OrdersRepository extends CrudRepository<Orders, Integer> {

    @Query(value = "SELECT o FROM Orders o WHERE o.orderId=:orderId")
    Orders findByOrderId(@Param("orderId") Integer orderId);

}
