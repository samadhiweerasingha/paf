package db;

import java.sql.Connection;
import java.sql.DriverManager;

public class databaseconnection {
	public static Connection createConnection() {
		
		Connection conn = null;
		String url = "jdbc:sql://localhost:3306/pafdb";
		
	
		String username = "root";
		String password = "root";
		
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				
			}
			catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			conn = DriverManager.getConnection(url,username,password);
			System.out.println("Printing connection object"+con);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
}
