package com.techstore.ordersapi;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class OrdersController {

    @Autowired
    private OrdersRepository OrdersRepository;



    /*@GetMapping("/users/{id}")
    public @ResponseBody User getUser(@PathVariable String id) {
        return userRepository.findById(Integer.parseInt(id)).get();
    }
    */

    @GetMapping("/orders")
    public @ResponseBody
    List<Orders> getAllOrders() {
        List<Orders> orders = new ArrayList<>();
        OrdersRepository.findAll().forEach(orders::add);
        return orders;
    }

    @PostMapping("/orders")
    public @ResponseBody Orders createOrders(@RequestBody  Orders orders) {
        return OrdersRepository.save(orders);
    }

    @DeleteMapping("/orders/{orderId}")
    public @ResponseBody void deleteoOrders(@PathVariable String orderId) {
        OrdersRepository.deleteById(Integer.parseInt(orderId));
    }

    @PutMapping("/orders/{orderId}")
    public @ResponseBody
    Orders UpdateOrders(@RequestBody Orders orders) {
        return OrdersRepository.save(orders);
    }
}








